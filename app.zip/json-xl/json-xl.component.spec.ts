import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JsonXlComponent } from './json-xl.component';

describe('JsonXlComponent', () => {
  let component: JsonXlComponent;
  let fixture: ComponentFixture<JsonXlComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JsonXlComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JsonXlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
