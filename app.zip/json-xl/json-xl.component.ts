import { Component,VERSION } from '@angular/core';

@Component({
  selector: 'app-json-xl',
  templateUrl: './json-xl.component.html',
  styleUrls: ['./json-xl.component.css']
})
export class JsonXlComponent   {

  willDownload=false;
  name = "Angular " + VERSION.major;
  convertedObj:any = "";
  convert(objArray:any) {
    console.log(objArray);
    this.convertedObj = JSON.stringify(objArray, null, 2);
    this.setDownload(this.convertedObj);
  }
  onError(err:any) {
    this.convertedObj = err
    console.log(err);
  }

  setDownload(data:any) {
    this.willDownload = true;
    setTimeout(() => {
      const el =<HTMLElement>document.querySelector("#download");
      el.setAttribute("href", `data:text/json;charset=utf-8,${encodeURIComponent(data)}`);
      el.setAttribute("download", 'csvtojson.json');
    }, 1000)
  }


}
