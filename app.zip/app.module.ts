import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { JToXComponent } from './j-to-x/j-to-x.component';
import { XlJsonComponent } from './xl-json/xl-json.component';
import { JsonXlComponent } from './json-xl/json-xl.component';
import { NgxCSVtoJSONModule } from 'ngx-csvto-json';
@NgModule({
  declarations: [
    AppComponent,
    JToXComponent,
    XlJsonComponent,
    JsonXlComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxCSVtoJSONModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
