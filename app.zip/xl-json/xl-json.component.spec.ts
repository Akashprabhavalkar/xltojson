import { ComponentFixture, TestBed } from '@angular/core/testing';

import { XlJsonComponent } from './xl-json.component';

describe('XlJsonComponent', () => {
  let component: XlJsonComponent;
  let fixture: ComponentFixture<XlJsonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ XlJsonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(XlJsonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
