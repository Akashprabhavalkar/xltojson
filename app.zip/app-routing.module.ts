import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { JsonXlComponent } from './json-xl/json-xl.component';
import { XlJsonComponent } from './xl-json/xl-json.component';

const routes: Routes = [
  {path:"xl",component:XlJsonComponent},
  {path:"json",component:JsonXlComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
