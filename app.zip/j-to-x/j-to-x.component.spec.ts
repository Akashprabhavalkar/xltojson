import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JToXComponent } from './j-to-x.component';

describe('JToXComponent', () => {
  let component: JToXComponent;
  let fixture: ComponentFixture<JToXComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JToXComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JToXComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
